﻿﻿from ast import Delete
import nextcord
from nextcord.ext import commands
import config
import aiohttp
import requests
import json
import datetime
from re import match

bot = commands.Bot(help_command=None)

async def logsend(embed):
  async with aiohttp.ClientSession() as session:
    webhook = nextcord.Webhook.from_url(config.webhook, session=session)
    await webhook.send(embed=embed)

class Topup(nextcord.ui.Modal):
    def __init__(self):
        super().__init__("เติมเงินผ่านระบบซองอั่งเปา")  
        self.topup = nextcord.ui.TextInput(
            label="เติมเงินด้วยอังเปา (ห้ามมีตัว # อยู่ในลิงค์)",
            placeholder="กรอกลิงค์ซองอั่งเปา💸💰 | URL",
            required=True
        )
        self.add_item(self.topup)
    async def callback(self, interaction: nextcord.Interaction):
        accdata = json.load(open('./acc_data/acc.json'))
        if (not match (r"https:\/\/gift\.truemoney\.com\/campaign\/\?v=+[a-zA-Z0-9]{18}", self.topup.value)):
           await interaction.send(f"เหมือนคุณจะกวนตีนบอท", ephemeral = True) 
           return
        voucher_code = self.topup.value.split("?v=")[1]
        response = requests.post(f"https://gift.truemoney.com/campaign/vouchers/{voucher_code}/redeem",json={"mobile": config.phone, "voucher_hash": voucher_code},headers={"Accept": "application/json","User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Safari/537.36","Content-Type": "application/json","Origin": "https://gift.truemoney.com","Accept-Language": "en-US,en;q=0.9","Connection": "keep-alive",})
        redeemdata = response.json()
        if response.status_code == 200 and redeemdata["status"]["code"] == "SUCCESS" :
            amount = float(redeemdata["data"]["my_ticket"]["amount_baht"])
            redeemdone = nextcord.Embed(description=f"`✅ เติมเงินสำเร็จ` `|` คุณ <@{interaction.user.id}> เติมเงินเข้ามาเป็นจำนวนเงิน {amount} บาท\n **{self.topup.value}**\nสร้างซองโดย : `{redeemdata['data']['owner_profile']['full_name']}`",color=0x00FF00)
            redeemdone.timestamp = datetime.datetime.utcnow()
            done = nextcord.Embed(description=f'`✅ เติมเงินสำเร็จ` `|` จำนวน `{amount}` บาท',color=0x32CD32)
            accdata[str(interaction.user.id)]["point"] += amount
            accdata[str(interaction.user.id)]["pointall"] += amount
            json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
            await interaction.send(embed=done,ephemeral=True)
            await logsend(embed=redeemdone)
        if response.status_code ==  400 or response.status_code == 404:
            await interaction.send(f"ซองอั่งเปานี้ถูกใช้ไปแล้ว หรือ ลิงค์อั่งเปาให้ถูกต้อง ", ephemeral = True)
  
class AddStock(nextcord.ui.Modal):
    def __init__(self):
        super().__init__("เพิ่มคีย์")  
        self.key = nextcord.ui.TextInput(
            label="คีย์",
            required=True,
            style=nextcord.TextInputStyle.paragraph
        )
        self.add_item(self.key)
    async def callback(self, interaction: nextcord.Interaction):
        f = open('key_data/key.txt','a')
        key = self.key.value
        if key in open('key_data/key.txt','r').read():
            await interaction.response.send_message(embed=nextcord.Embed(description=f"มีคีย์ `{key}` อยู่ใน database แล้ว!",color=0xff0000),ephemeral=True)
        else:
            if len(open('key_data/key.txt','r').readlines()) == 0:
                f.write(key)
                await interaction.response.send_message(embed=nextcord.Embed(description=f"เขียนคีย์ `{key}` ลง database แล้ว!",color=0x00ff00),ephemeral=True)
            else:
                f.write('\n')
                f.write(key)
                await interaction.response.send_message(embed=nextcord.Embed(description=f"เขียนคีย์ `{key}` ลง database แล้ว!",color=0x00ff00),ephemeral=True)

class RemoveStock(nextcord.ui.Modal):
    def __init__(self):
        super().__init__("ลบคีย์")  
        self.key = nextcord.ui.TextInput(
            label="คีย์",
            required=True
        )
        self.add_item(self.key)
    async def callback(self, interaction: nextcord.Interaction):
        f = open('key_data/key.txt','a')
        key = self.key.value
        if key not in open('key_data/key.txt','r').read():
            await interaction.send(embed=nextcord.Embed(description=f"ไม่มีคีย์ `{key}` อยู่ใน database!",color=0xff0000),ephemeral=True)
        else:
            lines = open("key_data/key.txt", "r").readlines()
            f = open("key_data/key.txt", "w")
            for line in lines:
                if line.strip("\n") != key:
                    f.write(line)
            await interaction.send(embed=nextcord.Embed(description=f"ลบคีย์ `{key}` ออกจาก database แล้ว!",color=0x00ff00),ephemeral=True)



class ButtonAdmin(nextcord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @nextcord.ui.button(label="เช็คสต็อคคีย์", style=nextcord.ButtonStyle.blurple, emoji="🧾",custom_id="เช็คสต็อค")
    async def stock(self, button: nextcord.Button, interaction: nextcord.Interaction):
                embed = nextcord.Embed(description=f"คีย์เหลือ `{len(open('key_data/key.txt').readlines())}` คีย์",color=0xFFFF00)
                await interaction.response.send_message(embed=embed,ephemeral=True)
    
    @nextcord.ui.button(label="(➕🔑) เพิ่มสต็อคคีย์", style=nextcord.ButtonStyle.blurple,custom_id="add")
    async def add(self, button: nextcord.Button, interaction: nextcord.Interaction):
                await interaction.response.send_modal(AddStock())
    
    @nextcord.ui.button(label="(➖🔑) ลบสต็อคคีย์", style=nextcord.ButtonStyle.blurple,custom_id="remove")
    async def remove(self, button: nextcord.Button, interaction: nextcord.Interaction):
                await interaction.response.send_modal(RemoveStock())



class Button(nextcord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @nextcord.ui.button(label="เติมเงิน", style=nextcord.ButtonStyle.blurple, emoji="🧧",custom_id="เติมเงิน")
    async def topup(self, button: nextcord.Button, interaction: nextcord.Interaction):
                if check(interaction.user.id) == False or True:
                    await interaction.response.send_modal(Topup())
    @nextcord.ui.button(label="เช็คบัญชิ", style=nextcord.ButtonStyle.blurple, emoji="💳",custom_id="เช็คบัญชิ")
    async def bal(self, button: nextcord.Button, interaction: nextcord.Interaction):
                if check(interaction.user.id) == False or True:
                  embed = nextcord.Embed(description=f"คุณมียอดเงินคงเหลือ `{json.load(open('./acc_data/acc.json'))[str(interaction.user.id)]['point']}` บาท\nคุณมียอดเติมสะสม `{json.load(open('./acc_data/acc.json'))[str(interaction.user.id)]['pointall']}` บาท",color=0xFFFF00)
                  await interaction.response.send_message(embed=embed,ephemeral=True)

    @nextcord.ui.button(label="ซื้อคีย์", style=nextcord.ButtonStyle.blurple, emoji="🛒",custom_id="buy")
    async def buy(self, button: nextcord.Button, interaction: nextcord.Interaction):
                embed = nextcord.Embed(title='ยืนยันการซื้อ',description='คุณแน่ใจที่จะซื้อใช่ไหม ?')
                ok = nextcord.ui.Button(label="ยืนยัน", style=nextcord.ButtonStyle.green, emoji="✅")
                no = nextcord.ui.Button(label="ไม่ล่ะ", style=nextcord.ButtonStyle.red, emoji="❌")  
                accdata = json.load(open('./acc_data/acc.json'))     
                role = nextcord.utils.get(interaction.guild.roles, id=config.roleid)   
                 
                async def ok_callback(interaction):
                    if role in interaction.user.roles: 
                        accdata[str(interaction.user.id)]["point"] -= config.key_price
                        json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
                        key = open("key_data/key.txt", "r").read().split('\n', 1)[0]  
                        await interaction.user.send(embed=nextcord.Embed(description=f"คีย์ที่คุณซื้อมาคือ ||{key}||",color=0x00ff00))
                        await msg.edit(content='ซื้อคีย์สำเร็จเช็ค DM', embed=None,view=None)
                        redeemdone = nextcord.Embed(description=f"`✅ ซื้อสำเร็จ` `|` คุณ <@{interaction.user.id}> ซื้อ `{key}`",color=0x00FF00)
                        redeemdone.timestamp = datetime.datetime.utcnow()
                        await logsend(embed=redeemdone)
                        x = open("key_data/key.txt", "r").readlines()
                        f = open("key_data/key.txt", "w")
                        for line in x:
                                if line.strip("\n") != key:
                                    f.write(line)
                    else:
                        await interaction.user.add_roles(interaction.guild.get_role(config.roleid))
                        accdata[str(interaction.user.id)]["point"] -= config.key_price
                        json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
                        key = open("key_data/key.txt", "r").read().split('\n', 1)[0]  
                        await interaction.user.send(embed=nextcord.Embed(description=f"คีย์ที่คุณซื้อมาคือ ||{key}||",color=0x00ff00))
                        await msg.edit(content='ซื้อคีย์สำเร็จเช็ค DM', embed=None,view=None)
                        redeemdone = nextcord.Embed(description=f"`✅ ซื้อสำเร็จ` `|` คุณ <@{interaction.user.id}> ซื้อ `{key}`",color=0x00FF00)
                        redeemdone.timestamp = datetime.datetime.utcnow()
                        await logsend(embed=redeemdone)
                        x = open("key_data/key.txt", "r").readlines()
                        f = open("key_data/key.txt", "w")
                        for line in x:
                                if line.strip("\n") != key:
                                    f.write(line)

                async def no_callback(interaction):
                    await msg.edit(content='ยกเลิกสำเร็จ', embed=None,view=None)

                no.callback = no_callback
                ok.callback = ok_callback
                myview = nextcord.ui.View()
                myview.add_item(ok)
                myview.add_item(no)
                
                
                if check(interaction.user.id) == False or True:
                    money = accdata[str(interaction.user.id)]['point']
                    if money < config.key_price:
                        need = config.key_price - money
                        await interaction.response.send_message(f'มีเงินไม่พอซื้อ (ขาดอีก {need} บาท) ',ephemeral=True)
                    else:
                     if len(open('key_data/key.txt','r').readlines()) == 0:
                        await interaction.response.send_message('หมด',ephemeral=True)
                     else:
                        msg = await interaction.response.send_message(embed=embed, view=myview,ephemeral=True) 

   
@bot.event
async def on_ready():
    bot.add_view(Button())
    bot.add_view(ButtonAdmin())
    print(f'BOT NAME : {bot.user}')
    await bot.change_presence(activity=nextcord.Streaming(name="Sell Bot",url="https://www.twitch.tv/anonymous_atm"))


@bot.slash_command(guild_ids=[config.guild_id],description="หน้าต่างเติมเงิน")
async def setup(interaction: nextcord.Interaction):
    if interaction.user.guild_permissions.administrator:
            embed = nextcord.Embed(title="Monkey Shop",color=0xe62063)
            embed.set_image(url="https://cdn.discordapp.com/attachments/1061057345997774848/1112324012463366195/332960240_226789163219684_6131145965216470611_n.png")
            await interaction.send('สำเร็จ',ephemeral=True)
            await interaction.channel.send(embed=embed, view=Button())
    else:
        await interaction.send('มึงไม่มีสิทธิ์ใช้ครับไอ้โง่',ephemeral=True)

@bot.slash_command(guild_ids=[config.guild_id],description="หน้าต่างแอดมิน")
async def setupadmin(interaction: nextcord.Interaction):
    if interaction.user.guild_permissions.administrator:
            embed = nextcord.Embed(title="หน้าต่างเมนูแอดมิน",color=0xFF6961)
            await interaction.send('สำเร็จ',ephemeral=True)
            await interaction.channel.send(embed=embed, view=ButtonAdmin())
    else:
        await interaction.send('มึงไม่มีสิทธิ์ใช้ครับไอ้โง่',ephemeral=True)

@bot.slash_command(guild_ids=[config.guild_id],description="ให้เงิน")
async def addpoint(interaction: nextcord.Interaction , user: nextcord.Member,amount: int):
    if interaction.user.guild_permissions.administrator:
       accdata = json.load(open('./acc_data/acc.json'))
       user_id = str(user.id)
       if check(user.id) == False or True:
         accdata[user_id]["point"] += amount
         json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
         await interaction.send(f"เพิ่มเงินให้ {user.mention} จำนวน {amount}",ephemeral=True)
       else:
          accdata[user_id]["point"] += amount
          json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
          await interaction.send(f"เพิ่มเงินให้ {user.mention} จำนวน {amount}",ephemeral=True)
    else:
        await interaction.send('มึงไม่มีสิทธิ์ใช้ครับไอ้โง่',ephemeral=True)

@bot.slash_command(guild_ids=[config.guild_id],description="ลบเงิน")
async def removepoint(interaction: nextcord.Interaction , user: nextcord.Member,amount: int):
    if interaction.user.guild_permissions.administrator:
       accdata = json.load(open('./acc_data/acc.json'))
       user_id = str(user.id)
       if check(user.id) == False or True:
        if accdata[user_id]['point'] >= amount:
          accdata[user_id]["point"] -= amount
          json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)
          await interaction.send(f"ลบเงินให้ {user.mention} จำนวน {amount}",ephemeral=True)
        else:
          await interaction.send(f"{user.mention} มีเงินไม่พอที่จะลบ",ephemeral=True)
    else:
        await interaction.send('มึงไม่มีสิทธิ์ใช้ครับไอ้โง่',ephemeral=True)

@bot.slash_command(guild_ids=[config.guild_id],description="ดูยอดเงินคนอื่น")
async def info(interaction: nextcord.Interaction , user: nextcord.Member):
  if interaction.user.guild_permissions.administrator:
       accdata = json.load(open('./acc_data/acc.json'))
       user_id = str(user.id)
       if check(user.id) == False or True:
        m = json.load(open('./acc_data/acc.json'))[str(user.id)]['point']
        mall = json.load(open('./acc_data/acc.json'))[str(user.id)]['pointall']
        embed = nextcord.Embed(description=f'ข้อมูลของ {user.mention}\nยอดเงินคงเหลือ `{m}` บาท\nมียอดเติมสะสม `{mall}` บาท')
        await interaction.send(embed=embed,ephemeral=True)
  else:
        await interaction.send('มึงไม่มีสิทธิ์ใช้ครับไอ้โง่',ephemeral=True)
        

def check(id):
        accdata = json.load(open('./acc_data/acc.json'))
        if str(id) in accdata:
            print(f'{id} in db')
            return True
        else:
            print(f'{id} not in db')
            accdata[id] = {
                "point" : 0,
                "pointall" : 0
            }
            json.dump(accdata, open("./acc_data/acc.json", "w"), indent = 4)


bot.run(config.token)