token = 'MTEyODk1NDA0NTM5MDkxMzYwOA.GZkueF.JBhWTwWyLsnS9owzZIA9X1eSdCWWGDPx5WgEBk'
guild_id = 1036122562817708072 #ไอดีเซิฟ
webhook = 'https://discord.com/api/webhooks/1036124762063249449/fC5EWrvxMbkpSZ3uVFKSTxFaPYROWWHNoHJE8g5ALinOva9_OHEu96VKIolU0cL-VyXe'
phone = '0824350956'

roleid = 1124880980734398494
key_price = 200 #ราคาคีย์